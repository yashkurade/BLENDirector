import bpy

from . import asset_cache


class BLENDIRECTOR_PT_panel(bpy.types.Panel):
    bl_label = "Blendirector"
    bl_idname = "BLENDIRECTOR_PT_panel"

    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Blendirector"

    def draw(self, context):

        layout = self.layout

        layout.operator("blendirector.refresh", icon='FILE_REFRESH')

        layout.separator()

        if not asset_cache:

            layout.label(text="No assets found", icon='ERROR')
            return

        # --------------------------------------------------
        # Category
        # --------------------------------------------------

        for category, presets in asset_cache.items():

            box = layout.box()

            box.label(text=category, icon='FILE_FOLDER')

            # ----------------------------------------------
            # Blend Files
            # ----------------------------------------------

            for preset, data in presets.items():

                sub = box.box()

                sub.label(text=preset, icon='FILE_BLEND')

                # ------------------------------------------
                # Collections
                # ------------------------------------------

                for collection in data["collections"]:

                    op = sub.operator(
                        "blendirector.append_collection",
                        text=collection,
                        icon='OUTLINER_COLLECTION'
                    )

                    op.category = category
                    op.preset = preset
                    op.collection_name = collection


classes = (
    BLENDIRECTOR_PT_panel,
)


def register():

    for c in classes:
        bpy.utils.register_class(c)


def unregister():

    for c in reversed(classes):
        bpy.utils.unregister_class(c)