import bpy

from . import asset_cache

expanded_categories = {}
expanded_presets = {}

class BLENDIRECTOR_OT_toggle_category(bpy.types.Operator):

    bl_idname = "blendirector.toggle_category"
    bl_label = "Toggle Category"

    category: bpy.props.StringProperty()

    def execute(self, context):

        expanded_categories[self.category] = not expanded_categories.get(self.category, True)

        return {'FINISHED'}


class BLENDIRECTOR_OT_toggle_preset(bpy.types.Operator):

    bl_idname = "blendirector.toggle_preset"
    bl_label = "Toggle Preset"

    key: bpy.props.StringProperty()

    def execute(self, context):

        expanded_presets[self.key] = not expanded_presets.get(self.key, True)

        return {'FINISHED'}

class BLENDIRECTOR_PT_panel(bpy.types.Panel):
    bl_label = "Blendirector"
    bl_idname = "BLENDIRECTOR_PT_panel"

    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Blendirector"

    def draw(self, context):

        layout = self.layout

        layout.operator("blendirector.refresh", icon='FILE_REFRESH')

        layout.separator()

        if not asset_cache:
            layout.label(text="No assets found", icon='ERROR')
            return

        for category, presets in asset_cache.items():

            expanded_categories.setdefault(category, False)

            category_box = layout.box()

            row = category_box.row()

            icon = 'TRIA_DOWN' if expanded_categories[category] else 'TRIA_RIGHT'

            op = row.operator(
                "blendirector.toggle_category",
                text=category,
                emboss=False,
                icon=icon
            )
            op.category = category

            if not expanded_categories[category]:
                continue

            for preset, data in presets.items():

                key = f"{category}/{preset}"

                expanded_presets.setdefault(key, False)

                preset_box = category_box.column(align=True)

                row = preset_box.row()

                icon = 'TRIA_DOWN' if expanded_presets[key] else 'TRIA_RIGHT'

                op = row.operator(
                    "blendirector.toggle_preset",
                    text=preset,
                    emboss=False,
                    icon=icon
                )
                op.key = key

                if not expanded_presets[key]:
                    continue

                col = preset_box.column(align=True)

                for collection in data["collections"]:

                    op = col.operator(
                        "blendirector.append_collection",
                        text=collection,
                        icon='OUTLINER_COLLECTION'
                    )

                    op.category = category
                    op.preset = preset
                    op.collection_name = collection


classes = (

    BLENDIRECTOR_OT_toggle_category,
    BLENDIRECTOR_OT_toggle_preset,
    BLENDIRECTOR_PT_panel,

)


def register():

    for c in classes:
        bpy.utils.register_class(c)


def unregister():

    for c in reversed(classes):
        bpy.utils.unregister_class(c)